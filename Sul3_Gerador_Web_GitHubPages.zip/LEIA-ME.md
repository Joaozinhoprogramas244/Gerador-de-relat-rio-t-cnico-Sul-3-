# Gerador de Relatório Técnico — Sul 3

Este pacote está preparado para publicação como site estático (HTTPS), por exemplo no GitHub Pages.

## Publicar no GitHub Pages
1. Entre em https://github.com e crie um repositório novo (pode ser privado ou público, conforme a disponibilidade do Pages na sua conta).
2. Envie o arquivo `index.html` para a raiz do repositório.
3. No repositório, abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
6. Aguarde a publicação e abra o endereço HTTPS exibido nessa mesma tela.

O arquivo `index.html` já é a página inicial. O site é estático: os dados preenchidos ficam no dispositivo/navegador e não são enviados a um servidor. A geração de PDF por jsPDF usa uma biblioteca carregada de CDN, então essa opção exige internet; a impressão do navegador continua sendo uma alternativa.

## Compatibilidade
A versão mantém o formulário, cadastro de 113 unidades e códigos CIE, pesquisa/seleção por toque, assinaturas, prévia, edição, limpeza e PDF. Teste a seleção de escolas e o fluxo de PDF nos navegadores-alvo após a publicação.
